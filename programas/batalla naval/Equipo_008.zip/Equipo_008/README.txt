Especificaciones: 
- El archivo 'batallanaval.py' es el archivo principal y el que debe ser ejecutado. El otro archivo ('ataque.py') es una 
libreria que guarda funcionas que luego son importadas desde archivo principal.

Instrucciones:
- Una vez iniciado deberá pulsar cualquier tecla (en especial la mencionada en el título).
- El sistema de coordenadas del plano tiene su punto origen en el (1, 1).
- Todas las entradas son validadas, por tanto, en el caso de que una entrada sea inválida, se volverá a pedir hasta cumplir los requisitos.
- Usted decidirá quien iniciará el juego, ya sea el jugador (usted) o la computadora (el sistema pseudo-aleatorio).

